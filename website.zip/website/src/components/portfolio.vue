<template>
  <section id="portfolio">
    <div class="row">
      <div class="col-12">
        <div class="section-heading">
          <h2>My projects</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-6">
        <div class="portfolio-item">
          <img src="../assets/karp-front-eng.png" alt="Yummy questions box">
          <h4>Yummy Questions</h4>
          <p>Yummy questions is an Estonian-based company that makes custom chocolate gift boxes. I made a full website for them.</p>
          <a class="btn" href="http://magusadkusimused.ee">Check it out</a>
        </div>
      </div>
      <div class="col-6">
        <div class="portfolio-item">
          <img src="../assets/mysteryproject.png" alt="Your project">
          <h4>Your next project</h4>
          <p>I would love to work with you on your next project.Tell me about it and let me know how I can help! I will always do my best.</p>
          <a class="btn" href="/#contact">Get in touch</a>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
  export default {
    name: "portfolio"
  }
</script>

<style scoped>

</style>
