<template>
    <nav>
      <ul>
        <li><a href="#hero">home</a></li>
        <li><a href="#intro">intro</a></li>
        <li><a href="$about">About me</a></li>
        <li><a href="#skills">My skillset</a></li>
        <li><a href="#portfolio">My projects</a></li>
        <li><a href="#contact">Contact me</a></li>
      </ul>
    </nav>
</template>

<script>
    export default {
        name: "navbar"
    }
</script>

<style scoped>

</style>
