<template>
  <div id="hero">
    <div class="row">
      <div class="col-12">
        <h1>Rauno Lillemets</h1>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <a href="#intro"><img src="../assets/icons/mouse.svg" alt=""></a>
      </div>
    </div>


  </div>
</template>

<script>
  export default {
    name: "hero"
  }
</script>

<style scoped>

</style>
